# BNPAT - Birth Nurse Pathway Application Tracker

A professional mobile application for tracking client application progress with advanced streak mechanics, AI motivational messages, and client sharing capabilities.

## ✨ Key Features

- **Enhanced Fire Streak System** - Growing fire visualization with color progression
- **Streak Restoration** - Recover dead streaks with 150+ applications in 48 hours  
- **Client Sharing Links** - Generate unique URLs for clients to view their progress
- **Push Notifications** - Smart reminder system with proper permission handling
- **Progress History** - Complete tracking with dates and totals
- **AI Motivational Messages** - Dynamic encouragement based on progress
- **Mobile-First Design** - Clean, professional interface optimized for mobile

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- PostgreSQL database

### Installation

1. Clone the repository:
```bash
git clone https://github.com/your-username/bnpat.git
cd bnpat
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
# Copy example env file
cp .env.example .env

# Add your database URL and other secrets
DATABASE_URL=your_postgresql_connection_string
SESSION_SECRET=your_session_secret
REPL_ID=your_replit_app_id
```

4. Set up the database:
```bash
npm run db:push
```

5. Start the development server:
```bash
npm run dev
```

## 🌐 Free Deployment Options

### 1. Vercel (Recommended for Frontend)
- Connect your GitHub repo to Vercel
- Automatic deployments on push
- Great for React/Vite apps
- Free tier includes custom domains

### 2. Railway (Recommended for Full-Stack)
- Perfect for Node.js + PostgreSQL
- Free $5/month credit
- Easy GitHub integration
- Built-in database hosting

### 3. Render
- Full-stack hosting with PostgreSQL
- Free tier available
- Direct GitHub deployment
- SSL certificates included

### 4. Netlify + Supabase
- Netlify for frontend hosting
- Supabase for PostgreSQL database
- Both have generous free tiers

## 📱 Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Node.js, Express.js, Drizzle ORM
- **Database**: PostgreSQL
- **Auth**: Replit Auth with OpenID Connect
- **Build**: Vite, esbuild

## 🔧 Project Structure

```
├── client/          # React frontend
├── server/          # Express backend  
├── shared/          # Shared TypeScript schemas
├── components.json  # shadcn/ui config
├── package.json     # Dependencies and scripts
└── README.md        # This file
```

## 📊 Features Deep Dive

### Fire Streak System
- 🔥 Orange (1-7 days)
- ❤️ Red (8-14 days) 
- 💗 Pink (15-21 days)
- 💜 Purple (22-28 days)
- 💙 Blue (29+ days - Legendary!)

### Client Sharing
- Generate secure share tokens
- Clients can bookmark their progress URL
- View-only access without admin features
- Real-time progress updates

### Smart Notifications
- Daily motivation messages
- Client-specific reminders
- Proper permission handling
- Fallback for unsupported browsers

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📄 License

MIT License - feel free to use this project for your birth nursing practice!

## 💬 Support

For questions about deployment or features, please open an issue on GitHub.