import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import ReminderSettings from "@/components/reminder-settings";
import { ClipboardList, Flame, ArrowLeft, LogOut } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { UserStreak } from "@shared/schema";

export default function Settings() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
  });

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Load user data into form
  useEffect(() => {
    if (user && typeof user === 'object' && 'firstName' in user) {
      setFormData({
        firstName: (user as any).firstName || "",
        lastName: (user as any).lastName || "",
        email: (user as any).email || "",
        password: "",
      });
    }
  }, [user]);

  const { data: streak } = useQuery<UserStreak>({
    queryKey: ["/api/streak"],
    enabled: isAuthenticated,
  });

  const logoutMutation = useMutation({
    mutationFn: () => apiRequest("/api/auth/logout", "POST"),
    onSuccess: () => {
      window.location.reload();
    },
    onError: () => {
      // Fallback - force reload anyway
      window.location.reload();
    },
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const handleSaveChanges = () => {
    // Note: In a real implementation, we would need an API endpoint to update user profile
    toast({
      title: "Feature Coming Soon",
      description: "Profile updates will be available in a future version",
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200 sticky top-0 z-40">
        <div className="px-4 py-4">
          <div className="flex items-center space-x-3">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => window.location.href = "/"}
              className="p-2 rounded-lg hover:bg-slate-100"
            >
              <ArrowLeft className="text-slate-600" size={20} />
            </Button>
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <ClipboardList className="text-white" size={20} />
              </div>
              <div>
                <h1 className="text-lg font-bold text-slate-800">Settings</h1>
                <p className="text-xs text-slate-600">Manage your profile</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="p-4 space-y-6">
        {/* Streak Display */}
        <Card className="shadow-sm border border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-slate-800">Current Streak</h3>
                <p className="text-sm text-slate-600">Days with 50+ applications added</p>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">{streak?.currentStreak || 0}</div>
                <div className="text-xs text-slate-500">days</div>
              </div>
            </div>
            <div className="mt-3 flex items-center text-sm text-slate-600">
              <Flame className="text-orange-500 mr-2" size={16} />
              {(streak?.currentStreak || 0) > 0 ? "Keep it up! You're on a roll!" : "Start your streak today!"}
            </div>
          </CardContent>
        </Card>

        {/* Reminder Settings */}
        <ReminderSettings />

        {/* Profile Settings */}
        <Card className="shadow-sm border border-slate-200">
          <CardHeader>
            <CardTitle className="text-slate-800">Profile Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName" className="text-sm font-medium text-slate-700">First Name</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="lastName" className="text-sm font-medium text-slate-700">Last Name</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  className="mt-1"
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="email" className="text-sm font-medium text-slate-700">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="mt-1"
              />
            </div>
            
            <div>
              <Label htmlFor="password" className="text-sm font-medium text-slate-700">New Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Leave blank to keep current password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="mt-1"
              />
            </div>
            
            <Button 
              onClick={handleSaveChanges}
              className="w-full bg-primary text-white hover:bg-primary/90"
            >
              Save Changes
            </Button>
          </CardContent>
        </Card>

        {/* App Info */}
        <Card className="shadow-sm border border-slate-200">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
                <ClipboardList className="text-white" size={24} />
              </div>
              <h3 className="font-semibold text-slate-800 mb-1">BNPAT</h3>
              <p className="text-sm text-slate-600">Birth Nurse Pathway Application Tracker</p>
              <p className="text-xs text-slate-500 mt-2">Version 1.0</p>
            </div>
          </CardContent>
        </Card>

        {/* Logout */}
        <Button 
          onClick={handleLogout}
          variant="destructive"
          className="w-full"
        >
          Sign Out
        </Button>
      </div>
    </div>
  );
}
