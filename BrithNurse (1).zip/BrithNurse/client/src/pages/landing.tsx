import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ClipboardList } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen app-gradient flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Card className="shadow-xl">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <div className="w-20 h-20 rounded-full overflow-hidden bg-white border-4 border-primary/20 shadow-lg mx-auto mb-4">
                <img 
                  src="/attached_assets/IMG-20240329-WA0012_1754753955288.jpg" 
                  alt="Birth Nurse Pathway Logo" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h1 className="text-2xl font-bold text-slate-800 mb-2">BNPAT</h1>
              <p className="text-slate-600 text-sm">Birth Nurse Pathway Application Tracker</p>
            </div>
            
            <Button 
              onClick={handleLogin}
              className="w-full bg-primary text-white py-3 font-semibold hover:bg-primary/90 transition-all duration-200 shadow-lg"
            >
              Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
