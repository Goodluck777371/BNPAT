import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import ClientCard from "@/components/client-card";
import AddClientForm from "@/components/add-client-form";
import ReceiptModal from "@/components/receipt-modal";
import AddProgressModal from "@/components/add-progress-modal";
import ShareClientModal from "@/components/share-client-modal";
import MotivationalBanner from "@/components/motivational-banner";
import StreakDisplay from "@/components/streak-display";
import BottomNav from "@/components/bottom-nav";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ClipboardList, Users, CheckCircle, Plus, Settings } from "lucide-react";
import { notificationScheduler } from "@/utils/notification-scheduler";
import type { Client } from "@shared/schema";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [showAddClient, setShowAddClient] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [showReceipt, setShowReceipt] = useState(false);
  const [showAddProgress, setShowAddProgress] = useState(false);
  const [progressClient, setProgressClient] = useState<Client | null>(null);
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareClient, setShareClient] = useState<Client | null>(null);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: clients = [], isLoading: clientsLoading } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
    enabled: isAuthenticated,
  });

  // Schedule notifications when clients data changes
  useEffect(() => {
    if (clients.length > 0) {
      notificationScheduler.scheduleClientReminders(clients);
      notificationScheduler.scheduleDailyMotivation();
    }
    
    return () => {
      notificationScheduler.clearAllReminders();
    };
  }, [clients]);

  const handleAddAmount = (clientId: string) => {
    const client = clients.find(c => c.id === clientId);
    if (client) {
      setProgressClient(client);
      setShowAddProgress(true);
    }
  };

  const handleShareProgress = (client: Client) => {
    setSelectedClient(client);
    setShowReceipt(true);
  };

  const handleShareLink = (clientId: string) => {
    const client = clients.find((c) => c.id === clientId);
    if (client) {
      setShareClient(client);
      setShowShareModal(true);
    }
  };

  if (isLoading || clientsLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  const completedClients = clients.filter((client) => client.isCompleted).length;

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200 sticky top-0 z-40">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-full overflow-hidden bg-white border-2 border-primary/20 shadow-sm">
                <img 
                  src="/attached_assets/IMG-20240329-WA0012_1754753955288.jpg" 
                  alt="Birth Nurse Pathway Logo" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h1 className="text-lg font-bold text-slate-800">BNPAT</h1>
                <p className="text-xs text-slate-600">Birth Nurse Pathway</p>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => window.location.href = "/settings"}
              className="p-2 rounded-lg hover:bg-slate-100"
            >
              <Settings className="text-slate-600" size={20} />
            </Button>
          </div>
        </div>
      </header>

      {/* Dashboard Content */}
      <div className="p-4">
        {/* Motivational Banner */}
        <div className="mb-4">
          <MotivationalBanner 
            completedClients={completedClients}
            totalClients={clients.length}
          />
        </div>

        {/* Streak Display */}
        <div className="mb-4">
          <StreakDisplay />
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Card className="shadow-sm border border-slate-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold text-slate-800">{clients.length}</p>
                  <p className="text-sm text-slate-600">Total Clients</p>
                </div>
                <div className="w-10 h-10 bg-secondary/10 rounded-lg flex items-center justify-center">
                  <Users className="text-secondary" size={20} />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-sm border border-slate-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold text-primary">{completedClients}</p>
                  <p className="text-sm text-slate-600">Completed</p>
                </div>
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <CheckCircle className="text-primary" size={20} />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Add Client Button */}
        {clients.length > 0 && (
          <div className="mb-4">
            <Button 
              onClick={() => setShowAddClient(true)} 
              className="w-full bg-primary hover:bg-primary/90 text-white font-semibold py-3 shadow-lg"
            >
              <Plus className="mr-2 h-5 w-5" />
              Add New Client
            </Button>
          </div>
        )}

        {/* Client Cards */}
        <div className="space-y-4">
          {clients.length === 0 ? (
            <Card className="shadow-sm border border-slate-200">
              <CardContent className="p-8 text-center">
                <ClipboardList className="mx-auto h-12 w-12 text-slate-400 mb-4" />
                <h3 className="text-lg font-medium text-slate-800 mb-2">No clients yet</h3>
                <p className="text-slate-600 mb-4">Add your first client to start tracking their progress</p>
                <Button onClick={() => setShowAddClient(true)} className="bg-primary hover:bg-primary/90">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Client
                </Button>
              </CardContent>
            </Card>
          ) : (
            clients.map((client) => (
              <ClientCard
                key={client.id}
                client={client}
                onAddAmount={handleAddAmount}
                onShareProgress={handleShareProgress}
                onShareLink={handleShareLink}
                isAddingProgress={false}
              />
            ))
          )}
        </div>
      </div>

      {/* Add Client Form */}
      {showAddClient && (
        <AddClientForm
          onClose={() => setShowAddClient(false)}
          onSuccess={() => {
            setShowAddClient(false);
            queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
          }}
        />
      )}

      {/* Receipt Modal */}
      {showReceipt && selectedClient && (
        <ReceiptModal
          client={selectedClient}
          onClose={() => {
            setShowReceipt(false);
            setSelectedClient(null);
          }}
        />
      )}

      {/* Add Progress Modal */}
      {showAddProgress && progressClient && (
        <AddProgressModal
          client={progressClient}
          onClose={() => {
            setShowAddProgress(false);
            setProgressClient(null);
          }}
        />
      )}

      {/* Share Client Modal */}
      {showShareModal && shareClient && (
        <ShareClientModal
          client={shareClient}
          onClose={() => {
            setShowShareModal(false);
            setShareClient(null);
          }}
        />
      )}

      {/* Bottom Navigation */}
      <BottomNav 
        activeSection="dashboard"
        onAddClient={() => setShowAddClient(true)}
      />
    </div>
  );
}
