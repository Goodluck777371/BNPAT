import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ClipboardList, Calendar, Clock, CheckCircle, TrendingUp } from "lucide-react";

interface PublicClient {
  id: string;
  name: string;
  appAmount: number;
  appDone: number;
  isCompleted: boolean;
  appDay: string;
  appTime: string;
  createdAt: string;
}

interface PublicProgressHistory {
  id: string;
  amount: number;
  createdAt: string;
}

export default function ClientShare() {
  const { shareToken } = useParams<{ shareToken: string }>();
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  const { data: client, isLoading: clientLoading, error: clientError } = useQuery<PublicClient>({
    queryKey: ["/api/public/client", shareToken],
    queryFn: async () => {
      const response = await fetch(`/api/public/client/${shareToken}`);
      if (!response.ok) {
        throw new Error('Client not found');
      }
      return response.json();
    },
    retry: false,
  });

  const { data: history = [], isLoading: historyLoading } = useQuery<PublicProgressHistory[]>({
    queryKey: ["/api/public/client", shareToken, "history"],
    queryFn: async () => {
      const response = await fetch(`/api/public/client/${shareToken}/history`);
      if (!response.ok) {
        throw new Error('History not found');
      }
      return response.json();
    },
    enabled: !!client,
    retry: false,
  });

  const formatDate = (dateString: string | Date) => {
    const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric", 
      year: "numeric"
    });
  };

  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  if (clientLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 rounded-full overflow-hidden bg-white border-4 border-blue-200 shadow-lg mx-auto mb-4 animate-pulse">
            <img 
              src="/attached_assets/IMG-20240329-WA0012_1754753955288.jpg" 
              alt="Birth Nurse Pathway Logo" 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading your progress...</p>
        </div>
      </div>
    );
  }

  if (clientError || !client) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex items-center justify-center">
        <Card className="w-full max-w-md mx-4 shadow-lg">
          <CardContent className="p-6 text-center">
            <div className="w-20 h-20 rounded-full overflow-hidden bg-white border-4 border-red-200 shadow-md mx-auto mb-4">
              <img 
                src="/attached_assets/IMG-20240329-WA0012_1754753955288.jpg" 
                alt="Birth Nurse Pathway Logo" 
                className="w-full h-full object-cover"
              />
            </div>
            <h3 className="font-semibold text-slate-800 mb-2">Progress Link Not Found</h3>
            <p className="text-sm text-slate-600">
              This progress link is invalid or has expired. Please contact your birth nurse for a new link.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const progressPercentage = Math.round((client.appDone / client.appAmount) * 100);
  const remainingApps = client.appAmount - client.appDone;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header with nursing background pattern */}
      <header className="bg-gradient-to-r from-blue-600 to-blue-700 shadow-lg sticky top-0 z-40 overflow-hidden relative">
        <div className="absolute inset-0 opacity-20 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTMwIDMwYzAtMTEuMDQ2LTguOTU0LTIwLTIwLTIwcy0yMCA4Ljk1NC0yMCAyMCA4Ljk1NCAyMCAyMCAyMCAyMC04Ljk1NCAyMC0yMHptMTAgMGMwLTExLjA0Ni04Ljk1NC0yMC0yMC0yMHMtMjAgOC45NTQtMjAgMjAgOC45NTQgMjAgMjAgMjAgMjAtOC45NTQgMjAtMjB6Ii8+PC9nPjwvZz48L3N2Zz4=')]"></div>
        <div className="max-w-2xl mx-auto px-4 py-6 relative">
          <div className="flex items-center justify-center space-x-4">
            <div className="w-14 h-14 rounded-full overflow-hidden bg-white border-3 border-white/30 shadow-lg">
              <img 
                src="/attached_assets/IMG-20240329-WA0012_1754753955288.jpg" 
                alt="Birth Nurse Pathway Logo" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="text-white text-center">
              <h1 className="text-xl font-bold">Your Progress</h1>
              <p className="text-blue-100 text-sm">Birth Nurse Pathway Tracker</p>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto p-4 space-y-6">
        {/* Welcome Card */}
        <Card className="bg-gradient-to-r from-blue-50 to-white border border-blue-200 shadow-lg">
          <CardContent className="p-6">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full overflow-hidden bg-white border-4 border-blue-200 shadow-md mx-auto mb-4">
                <img 
                  src="/attached_assets/IMG-20240329-WA0012_1754753955288.jpg" 
                  alt="Birth Nurse Pathway Logo" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h2 className="text-2xl font-bold text-slate-800 mb-2">Hello {client.name}!</h2>
              <p className="text-slate-600">Your Birth Nurse Pathway progress is tracked here</p>
              <p className="text-xs text-slate-500 mt-2 px-4 py-2 bg-blue-50 rounded-full inline-block">
                Last updated: {formatDate(currentTime)}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Progress Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="mr-2 text-primary" size={20} />
              Progress Overview
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">
                {client.appDone}<span className="text-2xl text-slate-500">/{client.appAmount}</span>
              </div>
              <p className="text-slate-600">Applications Completed</p>
              
              <div className="mt-4">
                <Progress value={progressPercentage} className="h-3" />
                <div className="flex justify-between text-sm text-slate-600 mt-2">
                  <span>{progressPercentage}% Complete</span>
                  <span>{remainingApps} Remaining</span>
                </div>
              </div>
              
              {client.isCompleted ? (
                <Badge className="mt-4 bg-green-100 text-green-800 border-green-200">
                  <CheckCircle className="mr-1" size={14} />
                  Completed! 🎉
                </Badge>
              ) : (
                <Badge variant="outline" className="mt-4">
                  In Progress
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Schedule Info */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-center space-x-6">
              <div className="flex items-center space-x-2 text-slate-600">
                <Calendar size={16} />
                <span className="text-sm">{client.appDay}s</span>
              </div>
              <div className="flex items-center space-x-2 text-slate-600">
                <Clock size={16} />
                <span className="text-sm">{formatTime(client.appTime)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Progress History */}
        <Card>
          <CardHeader>
            <CardTitle className="text-slate-800">Application History</CardTitle>
            <p className="text-sm text-slate-600">{history.length} total entries</p>
          </CardHeader>
          <CardContent>
            {historyLoading ? (
              <div className="text-center py-4">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
                <p className="text-sm text-slate-600">Loading history...</p>
              </div>
            ) : history.length === 0 ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <ClipboardList className="text-slate-400" size={32} />
                </div>
                <p className="text-slate-600 mb-2">No applications recorded yet</p>
                <p className="text-sm text-slate-500">Your progress will appear here as applications are submitted</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {history.map((entry) => (
                  <div key={entry.id} className="flex justify-between items-center bg-slate-50 rounded-lg p-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                        <span className="text-xs font-semibold text-primary">+{entry.amount}</span>
                      </div>
                      <div>
                        <p className="font-medium text-slate-800">{entry.amount} Applications</p>
                        <p className="text-xs text-slate-500">Added to your progress</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-slate-600">{formatDate(entry.createdAt)}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center py-6">
          <p className="text-xs text-slate-500">
            This progress is updated in real-time by your birth nurse
          </p>
          <p className="text-xs text-slate-400 mt-1">
            BNPAT - Birth Nurse Pathway Application Tracker
          </p>
        </div>
      </div>
    </div>
  );
}