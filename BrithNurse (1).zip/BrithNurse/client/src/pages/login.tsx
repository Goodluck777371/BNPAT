import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { loginSchema, type LoginRequest } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Lock, Eye, EyeOff } from "lucide-react";

export default function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const [showResetForm, setShowResetForm] = useState(false);
  const { toast } = useToast();

  const form = useForm<LoginRequest>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      password: "",
    },
  });

  const resetForm = useForm({
    defaultValues: {
      email: "gluck19999@gmail.com",
    },
  });

  const loginMutation = useMutation({
    mutationFn: (data: LoginRequest) => apiRequest("/api/auth/login", "POST", data),
    onSuccess: () => {
      window.location.reload();
    },
    onError: (error: any) => {
      toast({
        title: "Login Failed",
        description: error.message || "Invalid password",
        variant: "destructive",
      });
    },
  });

  const resetMutation = useMutation({
    mutationFn: (data: { email: string }) => apiRequest("/api/auth/request-reset", "POST", data),
    onSuccess: () => {
      toast({
        title: "Reset Email Sent",
        description: "Check your email for password reset instructions",
      });
      setShowResetForm(false);
    },
    onError: (error: any) => {
      toast({
        title: "Reset Failed",
        description: error.message || "Failed to send reset email",
        variant: "destructive",
      });
    },
  });

  const onLogin = (data: LoginRequest) => {
    loginMutation.mutate(data);
  };

  const onReset = (data: { email: string }) => {
    resetMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl border-blue-200">
        <CardHeader className="text-center space-y-4">
          <div className="w-20 h-20 rounded-full overflow-hidden bg-white border-4 border-blue-200 shadow-lg mx-auto">
            <img 
              src="/attached_assets/IMG-20240329-WA0012_1754753955288.jpg" 
              alt="Birth Nurse Pathway Logo" 
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <CardTitle className="text-2xl font-bold text-slate-800">Welcome Back</CardTitle>
            <p className="text-slate-600 mt-2">Enter your password to access BNPAT</p>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {!showResetForm ? (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onLogin)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-slate-700">Password</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                          <Input
                            {...field}
                            type={showPassword ? "text" : "password"}
                            placeholder="Enter your password"
                            className="pl-10 pr-10 border-slate-300 focus:border-blue-500"
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            {showPassword ? (
                              <EyeOff className="h-4 w-4 text-slate-400" />
                            ) : (
                              <Eye className="h-4 w-4 text-slate-400" />
                            )}
                          </Button>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  disabled={loginMutation.isPending}
                >
                  {loginMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Signing In...
                    </>
                  ) : (
                    "Sign In"
                  )}
                </Button>
              </form>
            </Form>
          ) : (
            <Form {...resetForm}>
              <form onSubmit={resetForm.handleSubmit(onReset)} className="space-y-4">
                <div className="text-center mb-4">
                  <h3 className="font-semibold text-slate-800">Reset Password</h3>
                  <p className="text-sm text-slate-600 mt-1">
                    We'll send reset instructions to your email
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-700">Email Address</label>
                  <Input
                    {...resetForm.register("email")}
                    type="email"
                    value="gluck19999@gmail.com"
                    disabled
                    className="mt-1 bg-slate-50 border-slate-300"
                  />
                </div>
                <div className="flex space-x-3">
                  <Button 
                    type="submit" 
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                    disabled={resetMutation.isPending}
                  >
                    {resetMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      "Send Reset Email"
                    )}
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={() => setShowResetForm(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Form>
          )}
          
          {!showResetForm && (
            <div className="text-center">
              <Button
                variant="link"
                onClick={() => setShowResetForm(true)}
                className="text-blue-600 hover:text-blue-700 text-sm"
              >
                Forgot your password?
              </Button>
            </div>
          )}
          
          <div className="text-center pt-4 border-t border-slate-200">
            <p className="text-xs text-slate-500">
              Birth Nurse Pathway Application Tracker
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}