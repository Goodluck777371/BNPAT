import type { Client } from "@shared/schema";

interface NotificationScheduler {
  scheduleClientReminders: (clients: Client[]) => void;
  clearAllReminders: () => void;
  scheduleReminder: (client: Client, hoursBefore: number) => void;
}

class ClientNotificationScheduler implements NotificationScheduler {
  private scheduledTimeouts: Set<NodeJS.Timeout> = new Set();

  scheduleClientReminders(clients: Client[]): void {
    // Clear existing reminders
    this.clearAllReminders();

    // Schedule reminders for each active client
    clients.forEach(client => {
      if (!client.isCompleted) {
        this.scheduleReminder(client, 1); // 1 hour before
      }
    });
  }

  scheduleReminder(client: Client, hoursBefore: number): void {
    if (!('Notification' in window) || Notification.permission !== 'granted') {
      return;
    }

    // Parse client's scheduled day and time
    const now = new Date();
    const currentDay = now.toLocaleDateString('en-US', { weekday: 'long' });
    
    // Only schedule if it's the client's application day
    if (client.appDay !== currentDay) {
      return;
    }

    // Parse the time (HH:MM format)
    const [hours, minutes] = client.appTime.split(':').map(Number);
    
    // Create reminder time (X hours before application time)
    const reminderTime = new Date();
    reminderTime.setHours(hours - hoursBefore, minutes, 0, 0);
    
    // Only schedule if reminder time is in the future
    if (reminderTime <= now) {
      return;
    }

    const timeUntilReminder = reminderTime.getTime() - now.getTime();
    
    const timeout = setTimeout(() => {
      const messages = [
        `Hey champ, we have a soul to save by ${client.appTime}! Get ready for ${client.name}'s application! 😉😜`,
        `Time to shine! ${client.name}'s application is due at ${client.appTime}. You got this! 💪`,
        `Reminder: ${client.name} needs your help by ${client.appTime}. Let's make it happen! ⭐`,
        `Application alert! ${client.name} is counting on you at ${client.appTime}. Ready to save the day? 🚀`
      ];

      const randomMessage = messages[Math.floor(Math.random() * messages.length)];
      
      new Notification("BNPAT Reminder", {
        body: randomMessage,
        icon: "/favicon.ico",
        badge: "/favicon.ico",
        tag: `client-${client.id}`,
        requireInteraction: true
      });

      // Remove timeout from set after execution
      this.scheduledTimeouts.delete(timeout);
    }, timeUntilReminder);

    this.scheduledTimeouts.add(timeout);
  }

  clearAllReminders(): void {
    this.scheduledTimeouts.forEach(timeout => {
      clearTimeout(timeout);
    });
    this.scheduledTimeouts.clear();
  }

  // Schedule daily motivation at 9 AM
  scheduleDailyMotivation(): void {
    const now = new Date();
    const motivationTime = new Date();
    motivationTime.setHours(9, 0, 0, 0);
    
    // If 9 AM has passed today, schedule for tomorrow
    if (motivationTime <= now) {
      motivationTime.setDate(motivationTime.getDate() + 1);
    }

    const timeUntilMotivation = motivationTime.getTime() - now.getTime();

    const timeout = setTimeout(() => {
      if (Notification.permission === 'granted') {
        const motivationalMessages = [
          "Good morning champion! Ready to change some lives today? 💪",
          "Rise and shine! Your clients are counting on you today! ⭐",
          "New day, new opportunities to make a difference! Let's go! 🚀",
          "Morning warrior! Time to track some amazing progress! 🌟"
        ];

        const randomMessage = motivationalMessages[Math.floor(Math.random() * motivationalMessages.length)];
        
        new Notification("Good Morning from BNPAT", {
          body: randomMessage,
          icon: "/favicon.ico",
          tag: "daily-motivation"
        });
      }

      // Reschedule for next day
      this.scheduleDailyMotivation();
    }, timeUntilMotivation);

    this.scheduledTimeouts.add(timeout);
  }
}

export const notificationScheduler = new ClientNotificationScheduler();