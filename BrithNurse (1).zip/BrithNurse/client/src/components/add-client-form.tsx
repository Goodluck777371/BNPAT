import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { insertClientSchema, type InsertClient } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X } from "lucide-react";

interface AddClientFormProps {
  onClose: () => void;
  onSuccess: () => void;
}

const weekdays = [
  "Monday",
  "Tuesday", 
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday"
];

export default function AddClientForm({ onClose, onSuccess }: AddClientFormProps) {
  const { toast } = useToast();
  const [selectedDay, setSelectedDay] = useState("");

  const form = useForm<InsertClient>({
    resolver: zodResolver(insertClientSchema),
    defaultValues: {
      name: "",
      email: "",
      appAmount: 0,
      appDay: "",
      appTime: "",
    },
  });

  const createClientMutation = useMutation({
    mutationFn: async (data: InsertClient) => {
      const response = await apiRequest("POST", "/api/clients", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Client added successfully!",
      });
      onSuccess();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add client",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertClient) => {
    createClientMutation.mutate(data);
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
      <div className="bg-white rounded-t-2xl w-full max-h-[80vh] overflow-y-auto">
        <div className="p-4 border-b border-slate-200">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-slate-800">Add New Client</h2>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-slate-100"
            >
              <X className="text-slate-400" size={20} />
            </Button>
          </div>
        </div>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="p-4 space-y-4">
          <div>
            <Label htmlFor="name" className="text-sm font-medium text-slate-700">Client Name</Label>
            <Input
              id="name"
              placeholder="Enter client name"
              {...form.register("name")}
              className="mt-1"
            />
            {form.formState.errors.name && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.name.message}</p>
            )}
          </div>
          
          <div>
            <Label htmlFor="email" className="text-sm font-medium text-slate-700">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="client@email.com"
              {...form.register("email")}
              className="mt-1"
            />
            {form.formState.errors.email && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.email.message}</p>
            )}
          </div>
          
          <div>
            <Label htmlFor="appAmount" className="text-sm font-medium text-slate-700">Application Amount</Label>
            <Input
              id="appAmount"
              type="number"
              placeholder="e.g., 200"
              {...form.register("appAmount", { valueAsNumber: true })}
              className="mt-1"
            />
            {form.formState.errors.appAmount && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.appAmount.message}</p>
            )}
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium text-slate-700">Application Day</Label>
              <Select onValueChange={(value) => {
                setSelectedDay(value);
                form.setValue("appDay", value);
              }}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select day" />
                </SelectTrigger>
                <SelectContent>
                  {weekdays.map((day) => (
                    <SelectItem key={day} value={day}>
                      {day}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.formState.errors.appDay && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.appDay.message}</p>
              )}
            </div>
            
            <div>
              <Label htmlFor="appTime" className="text-sm font-medium text-slate-700">Time</Label>
              <Input
                id="appTime"
                type="time"
                {...form.register("appTime")}
                className="mt-1"
              />
              {form.formState.errors.appTime && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.appTime.message}</p>
              )}
            </div>
          </div>
          
          <div className="pt-6 space-y-3">
            <Button 
              type="submit"
              disabled={createClientMutation.isPending}
              className="w-full bg-primary text-white font-semibold hover:bg-primary/90 h-12 text-base shadow-lg"
            >
              {createClientMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Saving Client...
                </>
              ) : (
                "Save Client & Start Tracking"
              )}
            </Button>
            <Button 
              type="button"
              variant="outline"
              onClick={onClose}
              className="w-full h-10"
            >
              Cancel
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
