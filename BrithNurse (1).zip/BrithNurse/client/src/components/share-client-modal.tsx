import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { X, Share, Copy, ExternalLink } from "lucide-react";
import type { Client } from "@shared/schema";

interface ShareClientModalProps {
  client: Client;
  onClose: () => void;
}

export default function ShareClientModal({ client, onClose }: ShareClientModalProps) {
  const { toast } = useToast();
  const [shareUrl, setShareUrl] = useState("");
  const [isGenerated, setIsGenerated] = useState(false);

  const generateShareLinkMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/clients/${client.id}/share`, {});
      return response.json();
    },
    onSuccess: (data) => {
      setShareUrl(data.shareUrl);
      setIsGenerated(true);
      toast({
        title: "Share Link Generated!",
        description: "Your client can now view their progress",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to generate share link",
        variant: "destructive",
      });
    },
  });

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      toast({
        title: "Copied!",
        description: "Share link copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Please copy the link manually",
        variant: "destructive",
      });
    }
  };

  const openInNewTab = () => {
    window.open(shareUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-lg">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Share className="text-primary" size={20} />
              <CardTitle>Share Progress with {client.name}</CardTitle>
            </div>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-slate-100"
            >
              <X className="text-slate-400" size={20} />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Client Preview */}
          <div className="bg-slate-50 rounded-lg p-4">
            <h3 className="font-semibold text-slate-800 mb-2">What {client.name} will see:</h3>
            <div className="space-y-2 text-sm text-slate-600">
              <p>• Their current application progress ({client.appDone}/{client.appAmount})</p>
              <p>• Complete history of all applications added</p>
              <p>• Progress percentage and completion status</p>
              <p>• Application schedule ({client.appDay}s at {client.appTime})</p>
            </div>
            <div className="mt-2 text-xs text-slate-500">
              ✨ They won't see other clients or have access to add progress
            </div>
          </div>

          {/* Generate or Display Link */}
          {!isGenerated ? (
            <div className="space-y-4">
              <div className="text-center py-4">
                <p className="text-sm text-slate-600 mb-4">
                  Create a special link for {client.name} to view their progress anytime
                </p>
                <Button 
                  onClick={() => generateShareLinkMutation.mutate()}
                  disabled={generateShareLinkMutation.isPending}
                  className="bg-primary text-white hover:bg-primary/90"
                >
                  {generateShareLinkMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Generating...
                    </>
                  ) : (
                    <>
                      <Share className="mr-2" size={16} />
                      Generate Share Link
                    </>
                  )}
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <Label htmlFor="shareUrl" className="text-sm font-medium text-slate-700">
                  Share Link for {client.name}
                </Label>
                <div className="flex space-x-2 mt-1">
                  <Input
                    id="shareUrl"
                    value={shareUrl}
                    readOnly
                    className="flex-1 font-mono text-xs"
                  />
                  <Button 
                    onClick={copyToClipboard}
                    variant="outline"
                    size="sm"
                    className="px-3"
                  >
                    <Copy size={16} />
                  </Button>
                  <Button 
                    onClick={openInNewTab}
                    variant="outline"
                    size="sm"
                    className="px-3"
                  >
                    <ExternalLink size={16} />
                  </Button>
                </div>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-1.5"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-green-800">Link Ready!</p>
                    <p className="text-xs text-green-600 mt-1">
                      Send this link to {client.name} via text, email, or any messaging app. 
                      They can bookmark it to check their progress anytime.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}