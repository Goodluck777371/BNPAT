import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, Sparkles } from "lucide-react";

interface MotivationalBannerProps {
  completedClients: number;
  totalClients: number;
  todayProgress?: number;
}

const motivationalMessages = [
  "Hey champ, we have souls to save today! 💪",
  "You're doing amazing work - keep going! ⭐",
  "Every application brings someone closer to their dream! 🌟",
  "Your dedication is making a real difference! 🚀",
  "Champions like you change lives, one app at a time! 👑",
  "The Birth Nurse Pathway needs heroes like you! 🏆",
  "You're crushing it! Time to add some progress! 🔥",
  "Ready to make magic happen today? ✨",
];

const completionMessages = [
  "You did it champ, application completed! Give yourself a treat! 🎉",
  "Another success story begins! You're unstoppable! 🌟",
  "Boom! That's how champions do it! 🏆",
  "You just changed someone's life forever! Amazing! ✨",
  "Victory dance time! Another dream unlocked! 💃",
];

export default function MotivationalBanner({ completedClients, totalClients, todayProgress = 0 }: MotivationalBannerProps) {
  const [currentMessage, setCurrentMessage] = useState("");
  const [showBanner, setShowBanner] = useState(true);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Show motivational message based on progress
    let message = "";
    
    if (completedClients === totalClients && totalClients > 0) {
      // All clients completed
      message = "🎊 Incredible! All clients completed! You're a true champion! 🎊";
    } else if (todayProgress >= 50) {
      // Good progress today
      message = completionMessages[Math.floor(Math.random() * completionMessages.length)];
    } else {
      // Regular motivation
      message = motivationalMessages[Math.floor(Math.random() * motivationalMessages.length)];
    }
    
    setCurrentMessage(message);
    
    // Show banner with animation
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 500);
    
    return () => clearTimeout(timer);
  }, [completedClients, totalClients, todayProgress]);

  // Auto-hide after 10 seconds
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        setIsVisible(false);
        setTimeout(() => setShowBanner(false), 300);
      }, 10000);
      
      return () => clearTimeout(timer);
    }
  }, [isVisible]);

  if (!showBanner) return null;

  return (
    <div className={`transition-all duration-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-2'}`}>
      <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border border-primary/20 shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-start justify-between">
            <div className="flex items-start space-x-3">
              <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center">
                <Sparkles className="text-primary" size={20} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-slate-800 leading-relaxed">
                  {currentMessage}
                </p>
                <p className="text-xs text-slate-600 mt-1">
                  Progress: {completedClients}/{totalClients} clients completed
                </p>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => {
                setIsVisible(false);
                setTimeout(() => setShowBanner(false), 300);
              }}
              className="p-1 rounded-lg hover:bg-slate-100"
            >
              <X className="text-slate-400" size={16} />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}