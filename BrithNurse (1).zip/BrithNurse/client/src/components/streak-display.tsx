import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Flame, Zap } from "lucide-react";

interface StreakData {
  currentStreak: number;
  lastActivityDate: string;
  isDead: boolean;
  canRestore: boolean;
  hoursLeftToRestore: number;
  applicationsNeededToRestore: number;
}

export default function StreakDisplay() {
  const { data: streak } = useQuery<StreakData>({
    queryKey: ["/api/streak"],
  });

  const [flameSize, setFlameSize] = useState(20);
  const [flameColor, setFlameColor] = useState("text-orange-500");

  useEffect(() => {
    if (streak?.currentStreak) {
      // Scale fire based on streak days
      const days = streak.currentStreak;
      if (days >= 30) {
        setFlameSize(36);
        setFlameColor("text-blue-500"); // Blue fire for epic streaks
      } else if (days >= 21) {
        setFlameSize(32);
        setFlameColor("text-purple-500");
      } else if (days >= 14) {
        setFlameSize(28);
        setFlameColor("text-pink-500");
      } else if (days >= 7) {
        setFlameSize(24);
        setFlameColor("text-red-500");
      } else {
        setFlameSize(20);
        setFlameColor("text-orange-500");
      }
    }
  }, [streak?.currentStreak]);

  if (!streak) return null;

  const getStreakEmoji = (days: number) => {
    if (days >= 30) return "🔥💙"; // Epic blue fire
    if (days >= 21) return "🔥💜"; // Purple fire
    if (days >= 14) return "🔥💗"; // Pink fire
    if (days >= 7) return "🔥❤️"; // Red fire
    if (days >= 3) return "🔥🧡"; // Orange fire
    if (days >= 1) return "🔥"; // Basic fire
    return "❄️"; // Dead streak
  };

  const getStreakLevel = (days: number) => {
    if (days >= 30) return "LEGENDARY";
    if (days >= 21) return "EPIC";
    if (days >= 14) return "MASTER";
    if (days >= 7) return "CHAMPION";
    if (days >= 3) return "RISING";
    if (days >= 1) return "ACTIVE";
    return "COLD";
  };

  return (
    <Card className={`shadow-sm border transition-all duration-300 ${
      streak.isDead ? 'border-slate-300 bg-slate-50' : 'border-orange-200 bg-gradient-to-r from-orange-50 to-red-50'
    }`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={`transition-all duration-500 ${streak.isDead ? 'opacity-50' : 'animate-pulse'}`}>
              {streak.isDead ? (
                <div className="w-10 h-10 bg-slate-200 rounded-full flex items-center justify-center">
                  <span className="text-lg">❄️</span>
                </div>
              ) : (
                <div className="relative">
                  <Flame 
                    className={`${flameColor} transition-all duration-500`} 
                    size={flameSize} 
                  />
                  {streak.currentStreak >= 7 && (
                    <Zap className="absolute -top-1 -right-1 text-yellow-400" size={12} />
                  )}
                </div>
              )}
            </div>
            
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="font-bold text-lg text-slate-800">
                  {streak.isDead ? 0 : streak.currentStreak} Day{streak.currentStreak !== 1 ? 's' : ''}
                </h3>
                <span className="text-lg">{getStreakEmoji(streak.isDead ? 0 : streak.currentStreak)}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Badge 
                  variant={streak.isDead ? "secondary" : "default"} 
                  className={`text-xs ${
                    streak.isDead ? 'bg-slate-200 text-slate-600' : 'bg-orange-100 text-orange-800'
                  }`}
                >
                  {getStreakLevel(streak.isDead ? 0 : streak.currentStreak)}
                </Badge>
                {!streak.isDead && streak.currentStreak >= 7 && (
                  <Badge className="text-xs bg-yellow-100 text-yellow-800">
                    ON FIRE! 🔥
                  </Badge>
                )}
              </div>
            </div>
          </div>
          
          <div className="text-right">
            {streak.isDead ? (
              <div className="space-y-1">
                <p className="text-sm font-medium text-red-600">Streak Lost</p>
                {streak.canRestore ? (
                  <div className="text-xs text-slate-600">
                    <p className="font-medium text-orange-600">⚡ RESTORE AVAILABLE</p>
                    <p>Complete 150+ apps in</p>
                    <p className="font-bold text-red-600">{streak.hoursLeftToRestore}h remaining</p>
                  </div>
                ) : (
                  <p className="text-xs text-slate-500">Start fresh!</p>
                )}
              </div>
            ) : (
              <div className="space-y-1">
                <p className="text-sm font-medium text-slate-600">Active Streak</p>
                <p className="text-xs text-slate-500">Keep going!</p>
              </div>
            )}
          </div>
        </div>
        
        {/* Progress visualization */}
        {!streak.isDead && (
          <div className="mt-3">
            <div className="flex items-center justify-between text-xs text-slate-600 mb-1">
              <span>Streak Power</span>
              <span>{Math.min(streak.currentStreak * 10, 100)}%</span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-2">
              <div 
                className={`h-2 rounded-full transition-all duration-1000 ${
                  streak.currentStreak >= 21 ? 'bg-gradient-to-r from-purple-500 to-blue-500' :
                  streak.currentStreak >= 14 ? 'bg-gradient-to-r from-pink-500 to-purple-500' :
                  streak.currentStreak >= 7 ? 'bg-gradient-to-r from-red-500 to-pink-500' :
                  'bg-gradient-to-r from-orange-500 to-red-500'
                }`}
                style={{ width: `${Math.min(streak.currentStreak * 10, 100)}%` }}
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}