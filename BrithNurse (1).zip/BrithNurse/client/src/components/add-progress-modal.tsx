import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { X, Plus } from "lucide-react";
import type { Client } from "@shared/schema";

interface AddProgressModalProps {
  client: Client;
  onClose: () => void;
}

const quickAmounts = [10, 25, 50, 100];

export default function AddProgressModal({ client, onClose }: AddProgressModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [amount, setAmount] = useState("");

  const addProgressMutation = useMutation({
    mutationFn: async (amount: number) => {
      const response = await apiRequest("POST", `/api/clients/${client.id}/progress`, { amount });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      queryClient.invalidateQueries({ queryKey: ["/api/clients", client.id, "history"] });
      toast({
        title: "Success!",
        description: `Added ${amount} applications for ${client.name}`,
      });
      onClose();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add application amount",
        variant: "destructive",
      });
    },
  });

  const handleQuickAdd = (quickAmount: number) => {
    addProgressMutation.mutate(quickAmount);
  };

  const handleCustomAdd = () => {
    const customAmount = parseInt(amount);
    if (customAmount > 0) {
      addProgressMutation.mutate(customAmount);
    } else {
      toast({
        title: "Invalid Amount",
        description: "Please enter a positive number",
        variant: "destructive",
      });
    }
  };

  const remainingApps = client.appAmount - client.appDone;
  const progressPercentage = Math.round((client.appDone / client.appAmount) * 100);

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-md">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-semibold text-slate-800">Add Applications</h3>
              <p className="text-sm text-slate-600">{client.name}</p>
            </div>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-slate-100"
            >
              <X className="text-slate-400" size={20} />
            </Button>
          </div>

          {/* Progress Info */}
          <div className="bg-slate-50 rounded-lg p-3 mb-4">
            <div className="flex justify-between text-sm mb-1">
              <span>Current Progress</span>
              <span className="font-medium">{progressPercentage}%</span>
            </div>
            <div className="text-xs text-slate-600">
              {client.appDone}/{client.appAmount} completed • {remainingApps} remaining
            </div>
          </div>

          {/* Quick Add Buttons */}
          <div className="mb-4">
            <Label className="text-sm font-medium text-slate-700 mb-2 block">Quick Add</Label>
            <div className="grid grid-cols-2 gap-2">
              {quickAmounts.map((quickAmount) => (
                <Button
                  key={quickAmount}
                  variant="outline"
                  onClick={() => handleQuickAdd(quickAmount)}
                  disabled={addProgressMutation.isPending}
                  className="flex items-center justify-center py-2"
                >
                  <Plus className="mr-1" size={16} />
                  {quickAmount}
                </Button>
              ))}
            </div>
          </div>

          {/* Custom Amount */}
          <div className="mb-6">
            <Label htmlFor="customAmount" className="text-sm font-medium text-slate-700 mb-2 block">
              Custom Amount
            </Label>
            <div className="flex space-x-2">
              <Input
                id="customAmount"
                type="number"
                placeholder="Enter amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="flex-1"
                min="1"
              />
              <Button 
                onClick={handleCustomAdd}
                disabled={addProgressMutation.isPending || !amount}
                className="bg-primary text-white hover:bg-primary/90"
              >
                <Plus className="mr-1" size={16} />
                Add
              </Button>
            </div>
          </div>

          {/* Loading State */}
          {addProgressMutation.isPending && (
            <div className="text-center py-2">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto"></div>
              <p className="text-sm text-slate-600 mt-2">Adding applications...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}