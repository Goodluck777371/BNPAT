import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ClipboardList, Download, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Client } from "@shared/schema";

interface ReceiptModalProps {
  client: Client;
  onClose: () => void;
}

export default function ReceiptModal({ client, onClose }: ReceiptModalProps) {
  const { toast } = useToast();
  
  const progressPercentage = Math.round((client.appDone / client.appAmount) * 100);
  const remainingApps = client.appAmount - client.appDone;
  const currentDate = new Date().toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });

  const handleDownload = () => {
    // Create text content for sharing
    const receiptText = `
BNPAT Progress Report
Birth Nurse Pathway Application Tracker
${currentDate}

Client: ${client.name}
Email: ${client.email}
Target Applications: ${client.appAmount}
Completed: ${client.appDone}
Remaining: ${remainingApps}
Progress: ${progressPercentage}%

Status: ${client.isCompleted ? "✅ COMPLETED" : "In Progress"}
${client.isCompleted ? "Congratulations on completing the Birth Nurse Pathway!" : "Keep up the great work!"}
    `.trim();

    // Create downloadable text file
    const blob = new Blob([receiptText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${client.name}_progress_report.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: "Success",
      description: "Progress report downloaded successfully!",
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-md">
        <div className="p-6">
          {/* Receipt Header */}
          <div className="text-center border-b border-slate-200 pb-4 mb-4">
            <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
              <ClipboardList className="text-white" size={24} />
            </div>
            <h3 className="font-bold text-slate-800">BNPAT Progress Report</h3>
            <p className="text-xs text-slate-600">Birth Nurse Pathway Application Tracker</p>
            <p className="text-xs text-slate-500 mt-1">{currentDate}</p>
          </div>

          {/* Client Details */}
          <div className="space-y-3 mb-6">
            <div className="flex justify-between">
              <span className="text-sm text-slate-600">Client:</span>
              <span className="text-sm font-medium">{client.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-slate-600">Email:</span>
              <span className="text-sm font-medium">{client.email}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-slate-600">Target Applications:</span>
              <span className="text-sm font-medium">{client.appAmount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-slate-600">Completed:</span>
              <span className="text-sm font-medium text-primary">{client.appDone}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-slate-600">Remaining:</span>
              <span className="text-sm font-medium">{remainingApps}</span>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mb-6">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-slate-600">Progress</span>
              <span className="font-medium">{progressPercentage}%</span>
            </div>
            <Progress value={progressPercentage} className="h-3" />
          </div>

          {/* Status */}
          <div className="text-center mb-6">
            {client.isCompleted ? (
              <div className="success-gradient border border-success/20 rounded-lg p-3">
                <p className="text-sm font-medium text-success">✅ COMPLETED</p>
                <p className="text-xs text-success/80">Congratulations on completing the Birth Nurse Pathway!</p>
              </div>
            ) : (
              <div className="bg-primary/10 border border-primary/20 rounded-lg p-3">
                <p className="text-sm font-medium text-primary">In Progress</p>
                <p className="text-xs text-primary/80">Keep up the great work!</p>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex space-x-3">
            <Button 
              onClick={onClose}
              variant="outline"
              className="flex-1"
            >
              Close
            </Button>
            <Button 
              onClick={handleDownload}
              className="flex-1 bg-primary text-white hover:bg-primary/90"
            >
              <Download className="mr-1" size={16} />
              Share
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
