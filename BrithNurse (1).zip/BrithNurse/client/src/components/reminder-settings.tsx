import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Bell, Clock, MessageSquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ReminderSettings() {
  const { toast } = useToast();
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [reminderTime, setReminderTime] = useState("1"); // 1 hour before
  const [motivationalMessages, setMotivationalMessages] = useState(true);

  useEffect(() => {
    // Check if notifications are supported
    if ('Notification' in window) {
      setNotificationsEnabled(Notification.permission === 'granted');
    }
  }, []);

  const requestNotificationPermission = async () => {
    if (!('Notification' in window)) {
      toast({
        title: "Not Supported",
        description: "Your browser doesn't support notifications",
        variant: "destructive",
      });
      return;
    }

    // Check current permission state
    if (Notification.permission === 'granted') {
      setNotificationsEnabled(true);
      toast({
        title: "Already Enabled!",
        description: "Notifications are working perfectly",
      });
      return;
    }

    if (Notification.permission === 'denied') {
      toast({
        title: "Permission Blocked",
        description: "Please reset notification permissions in your browser settings",
        variant: "destructive",
      });
      return;
    }

    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        setNotificationsEnabled(true);
        toast({
          title: "Notifications Enabled!",
          description: "You'll now receive reminders for client applications",
        });
        
        // Send a test notification
        setTimeout(() => {
          new Notification("BNPAT Reminder", {
            body: "Hey champ, we have souls to save! Get ready for today's applications! 💪",
            icon: "/favicon.ico"
          });
        }, 1000);
      } else {
        setNotificationsEnabled(false);
        toast({
          title: "Permission Denied",
          description: "Notifications won't work without permission",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Notification permission error:', error);
      toast({
        title: "Error",
        description: "Failed to enable notifications",
        variant: "destructive",
      });
    }
  };

  const disableNotifications = () => {
    setNotificationsEnabled(false);
    toast({
      title: "Notifications Disabled",
      description: "You won't receive reminder notifications anymore",
    });
  };

  return (
    <Card className="shadow-sm border border-slate-200">
      <CardHeader>
        <CardTitle className="text-slate-800 flex items-center">
          <Bell className="mr-2" size={20} />
          Reminder Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Notification Permission */}
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <Label className="text-sm font-medium text-slate-700">Push Notifications</Label>
            <p className="text-xs text-slate-600">Get reminded about client application times</p>
          </div>
          <div className="flex items-center space-x-2">
            <Switch 
              checked={notificationsEnabled}
              onCheckedChange={notificationsEnabled ? disableNotifications : requestNotificationPermission}
            />
          </div>
        </div>

        {/* Reminder Timing */}
        <div className="space-y-2">
          <Label className="text-sm font-medium text-slate-700 flex items-center">
            <Clock className="mr-1" size={16} />
            Reminder Time
          </Label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { value: "0.5", label: "30 min" },
              { value: "1", label: "1 hour" },
              { value: "2", label: "2 hours" }
            ].map((option) => (
              <Button
                key={option.value}
                variant={reminderTime === option.value ? "default" : "outline"}
                size="sm"
                onClick={() => setReminderTime(option.value)}
                className={reminderTime === option.value ? "bg-primary text-white" : ""}
              >
                {option.label}
              </Button>
            ))}
          </div>
          <p className="text-xs text-slate-500">How early to remind you before application time</p>
        </div>

        {/* Motivational Messages */}
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <Label className="text-sm font-medium text-slate-700 flex items-center">
              <MessageSquare className="mr-1" size={16} />
              AI Motivational Messages
            </Label>
            <p className="text-xs text-slate-600">Show encouraging messages in the app</p>
          </div>
          <Switch 
            checked={motivationalMessages}
            onCheckedChange={setMotivationalMessages}
          />
        </div>

        {/* Test Notification */}
        <div className="pt-2 border-t border-slate-100">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              if (notificationsEnabled) {
                new Notification("BNPAT Test Reminder", {
                  body: "Hey champ, we have souls to save! Time to check your applications! 😉",
                  icon: "/favicon.ico"
                });
                toast({
                  title: "Test Sent!",
                  description: "Check your notification",
                });
              } else {
                toast({
                  title: "Enable Notifications First",
                  description: "Turn on notifications to test reminders",
                  variant: "destructive",
                });
              }
            }}
            className="w-full"
          >
            Test Notification
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}