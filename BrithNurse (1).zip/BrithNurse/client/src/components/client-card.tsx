import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Share, Plus, Link } from "lucide-react";
import type { Client, ProgressHistory } from "@shared/schema";

interface ClientCardProps {
  client: Client;
  onAddAmount: (clientId: string) => void;
  onShareProgress: (client: Client) => void;
  onShareLink: (clientId: string) => void;
  isAddingProgress: boolean;
}

export default function ClientCard({ client, onAddAmount, onShareProgress, onShareLink, isAddingProgress }: ClientCardProps) {
  const { data: history = [] } = useQuery<ProgressHistory[]>({
    queryKey: ["/api/clients", client.id, "history"],
  });

  const progressPercentage = Math.round((client.appDone / client.appAmount) * 100);
  const remainingApps = client.appAmount - client.appDone;

  const formatDate = (dateString: string | Date) => {
    const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
    return date.toLocaleDateString("en-US", {
      month: "2-digit",
      day: "2-digit", 
      year: "numeric"
    });
  };

  return (
    <Card className="shadow-sm border border-slate-200 overflow-hidden">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h3 className="font-semibold text-slate-800">{client.name}</h3>
            <p className="text-sm text-slate-600">{client.email}</p>
            <p className="text-xs text-slate-500 mt-1">
              {client.appDay}s at {client.appTime}
            </p>
          </div>
          <div className="flex items-center space-x-2">
            {client.isCompleted && (
              <span className="bg-success text-white px-2 py-1 rounded-full text-xs font-medium">
                ✅ COMPLETED
              </span>
            )}
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onShareProgress(client)}
              className="p-2 rounded-lg hover:bg-slate-100"
              title="Share Receipt"
            >
              <Share className="text-slate-400" size={16} />
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onShareLink(client.id)}
              className="p-2 rounded-lg hover:bg-slate-100"
              title="Create Client Link"
            >
              <Link className="text-slate-400" size={16} />
            </Button>
          </div>
        </div>
        
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-slate-600">Progress</span>
            <span className={`font-medium ${client.isCompleted ? 'text-success' : ''}`}>
              {client.appDone}/{client.appAmount} Apps
            </span>
          </div>
          
          <Progress 
            value={progressPercentage} 
            className="h-2"
          />
          
          {client.isCompleted ? (
            <div className="success-gradient border border-success/20 rounded-lg p-3">
              <p className="text-sm font-medium text-success text-center">
                🎉 You did it champ, application completed! Give yourself a treat!
              </p>
              <p className="text-xs text-success/80 text-center mt-1">Birth Nurse Pathway</p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">{progressPercentage}% Complete</span>
                <span className="text-sm font-medium text-slate-800">{remainingApps} apps left</span>
              </div>
              <Button 
                onClick={() => onAddAmount(client.id)}
                disabled={isAddingProgress}
                className="w-full bg-primary text-white py-2.5 text-sm font-semibold hover:bg-primary/90 shadow-md"
              >
                <Plus className="mr-2" size={18} />
                {isAddingProgress ? "Adding..." : "Add Application Amount"}
              </Button>
            </div>
          )}
        </div>
        
        {/* Complete History Log */}
        {history.length > 0 && (
          <div className="mt-4 pt-3 border-t border-slate-100">
            <div className="flex justify-between items-center mb-2">
              <p className="text-xs font-medium text-slate-600">Application History</p>
              <p className="text-xs text-slate-500">{history.length} entries</p>
            </div>
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {history.map((entry) => (
                <div key={entry.id} className="flex justify-between items-center bg-slate-50 rounded-lg p-2">
                  <span className="text-xs font-medium text-primary">+{entry.amount} Apps</span>
                  <span className="text-xs text-slate-500">{formatDate(entry.createdAt || new Date().toISOString())}</span>
                </div>
              ))}
            </div>
            <div className="mt-2 pt-2 border-t border-slate-100">
              <p className="text-xs text-slate-600">
                Total added: <span className="font-medium text-primary">{history.reduce((sum, entry) => sum + entry.amount, 0)} applications</span>
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
