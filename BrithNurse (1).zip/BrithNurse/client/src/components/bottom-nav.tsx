import { Button } from "@/components/ui/button";
import { Home, Plus, Settings } from "lucide-react";
import { useLocation } from "wouter";

interface BottomNavProps {
  activeSection: "dashboard" | "settings";
  onAddClient: () => void;
}

export default function BottomNav({ activeSection, onAddClient }: BottomNavProps) {
  const [, setLocation] = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-4 py-2 z-50">
      <div className="flex items-center justify-between">
        <Button 
          variant="ghost"
          onClick={() => setLocation("/")}
          className={`flex flex-col items-center space-y-1 py-2 px-3 rounded-lg transition-colors ${
            activeSection === "dashboard" 
              ? "text-primary" 
              : "text-slate-400 hover:text-slate-600"
          }`}
        >
          <Home size={20} />
          <span className="text-xs font-medium">Dashboard</span>
        </Button>
        
        <Button 
          onClick={onAddClient}
          className="bg-primary text-white p-4 rounded-full shadow-lg hover:bg-primary/90 hover:shadow-xl transition-all duration-200 transform hover:scale-105"
        >
          <Plus size={24} />
        </Button>
        
        <Button 
          variant="ghost"
          onClick={() => setLocation("/settings")}
          className={`flex flex-col items-center space-y-1 py-2 px-3 rounded-lg transition-colors ${
            activeSection === "settings" 
              ? "text-primary" 
              : "text-slate-400 hover:text-slate-600"
          }`}
        >
          <Settings size={20} />
          <span className="text-xs">Settings</span>
        </Button>
      </div>
    </nav>
  );
}
