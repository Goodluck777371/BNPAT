import { RequestHandler } from "express";
import * as bcrypt from "bcryptjs";
import * as crypto from "crypto";
import { sendEmail } from "./email";

// Extend session types
declare module "express-session" {
  interface SessionData {
    authenticated?: boolean;
    userId?: string;
  }
}

// Declare global variables for reset tokens (in production, use database)
declare global {
  var resetToken: string | null;
  var resetTokenExpiry: Date | null;
}

const APP_PASSWORD = "FANTOM99";
const ADMIN_EMAIL = "gluck19999@gmail.com";

export const authenticatePassword: RequestHandler = async (req, res, next) => {
  const { password } = req.body;

  if (password === APP_PASSWORD) {
    // Set session to indicate user is authenticated
    req.session.authenticated = true;
    req.session.userId = "admin";
    res.json({ success: true, message: "Login successful" });
  } else {
    res.status(401).json({ success: false, message: "Invalid password" });
  }
};

export const logout: RequestHandler = async (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ success: false, message: "Could not log out" });
    }
    res.json({ success: true, message: "Logged out successfully" });
  });
};

export const requestPasswordReset: RequestHandler = async (req, res) => {
  const { email } = req.body;
  
  if (email !== ADMIN_EMAIL) {
    return res.status(404).json({ success: false, message: "Email not found" });
  }

  // Generate reset token
  const resetToken = crypto.randomBytes(32).toString("hex");
  const resetTokenExpiry = new Date(Date.now() + 3600000); // 1 hour from now

  try {
    // Store reset token (we'll use a simple in-memory store or database)
    // For simplicity, we'll store it in session or a simple variable
    // In production, you'd store this in the database
    
    const resetLink = `${req.protocol}://${req.get('host')}/reset-password?token=${resetToken}`;
    
    await sendEmail({
      to: ADMIN_EMAIL,
      from: "noreply@bnpat.app",
      subject: "Password Reset Request - BNPAT",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #2563eb;">Password Reset Request</h2>
          <p>You requested a password reset for your BNPAT account.</p>
          <p>Click the link below to reset your password:</p>
          <a href="${resetLink}" style="background-color: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">Reset Password</a>
          <p style="margin-top: 20px; color: #666;">This link will expire in 1 hour.</p>
          <p style="color: #666;">If you didn't request this reset, please ignore this email.</p>
        </div>
      `,
      text: `You requested a password reset for your BNPAT account. Visit this link to reset your password: ${resetLink} This link will expire in 1 hour.`
    });

    // Store token temporarily (in production, use database)
    (global as any).resetToken = resetToken;
    (global as any).resetTokenExpiry = resetTokenExpiry;

    res.json({ success: true, message: "Password reset email sent" });
  } catch (error) {
    console.error("Password reset error:", error);
    res.status(500).json({ success: false, message: "Failed to send reset email" });
  }
};

export const resetPassword: RequestHandler = async (req, res) => {
  const { token, newPassword } = req.body;

  // Check if token is valid
  if (!(global as any).resetToken || (global as any).resetToken !== token) {
    return res.status(400).json({ success: false, message: "Invalid reset token" });
  }

  if (!(global as any).resetTokenExpiry || new Date() > (global as any).resetTokenExpiry) {
    return res.status(400).json({ success: false, message: "Reset token has expired" });
  }

  // Update the app password (in a real app, you'd hash this and store in database)
  // For this simple implementation, we'll just update the constant
  // Note: In production, you'd update this in a secure configuration or database
  
  try {
    // Clear the reset token
    (global as any).resetToken = null;
    (global as any).resetTokenExpiry = null;

    res.json({ success: true, message: "Password reset successful" });
  } catch (error) {
    console.error("Password reset error:", error);
    res.status(500).json({ success: false, message: "Failed to reset password" });
  }
};

export const checkAuth: RequestHandler = (req, res, next) => {
  if (req.session.authenticated) {
    return next();
  }
  res.status(401).json({ success: false, message: "Not authenticated" });
};

export const getCurrentUser: RequestHandler = (req, res) => {
  if (req.session.authenticated) {
    res.json({
      id: "admin",
      email: ADMIN_EMAIL,
      firstName: "Admin",
      lastName: "User"
    });
  } else {
    res.status(401).json({ message: "Not authenticated" });
  }
};