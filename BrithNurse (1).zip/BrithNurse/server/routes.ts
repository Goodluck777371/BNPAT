import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  authenticatePassword, 
  logout, 
  requestPasswordReset, 
  resetPassword, 
  checkAuth, 
  getCurrentUser 
} from "./auth";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import { insertClientSchema, updateClientProgressSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Session middleware
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPgSimple(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions",
  });
  
  app.set("trust proxy", 1);
  app.use(session({
    secret: process.env.SESSION_SECRET || "fallback-secret-key",
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: false, // Set to true in production with HTTPS
      maxAge: sessionTtl,
    },
  }));

  // Auth routes
  app.post("/api/auth/login", authenticatePassword);
  app.post("/api/auth/logout", logout);
  app.post("/api/auth/request-reset", requestPasswordReset);
  app.post("/api/auth/reset-password", resetPassword);
  app.get("/api/auth/user", getCurrentUser);

  // Client routes
  app.post("/api/clients", checkAuth, async (req: any, res) => {
    try {
      const userId = "admin";
      const clientData = insertClientSchema.parse(req.body);
      const client = await storage.createClient(userId, clientData);
      res.json(client);
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ message: "Invalid client data", errors: error.errors });
      } else {
        console.error("Error creating client:", error);
        res.status(500).json({ message: "Failed to create client" });
      }
    }
  });

  app.get("/api/clients", checkAuth, async (req: any, res) => {
    try {
      const userId = "admin";
      const clients = await storage.getClientsByUserId(userId);
      res.json(clients);
    } catch (error) {
      console.error("Error fetching clients:", error);
      res.status(500).json({ message: "Failed to fetch clients" });
    }
  });

  app.get("/api/clients/:id", checkAuth, async (req: any, res) => {
    try {
      const client = await storage.getClient(req.params.id);
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }
      res.json(client);
    } catch (error) {
      console.error("Error fetching client:", error);
      res.status(500).json({ message: "Failed to fetch client" });
    }
  });

  app.post("/api/clients/:id/progress", checkAuth, async (req: any, res) => {
    try {
      const { amount } = updateClientProgressSchema.parse(req.body);
      const clientId = req.params.id;
      const userId = "admin";

      // Update client progress
      const updatedClient = await storage.updateClientProgress(clientId, amount);
      
      // Add to progress history
      await storage.addProgressHistory(clientId, amount);

      // Update user streak
      await updateUserStreakForToday(userId, amount);

      res.json(updatedClient);
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ message: "Invalid progress data", errors: error.errors });
      } else {
        console.error("Error updating client progress:", error);
        res.status(500).json({ message: "Failed to update progress" });
      }
    }
  });

  app.get("/api/clients/:id/history", checkAuth, async (req: any, res) => {
    try {
      const history = await storage.getProgressHistory(req.params.id);
      res.json(history);
    } catch (error) {
      console.error("Error fetching progress history:", error);
      res.status(500).json({ message: "Failed to fetch progress history" });
    }
  });

  // User streak routes with restoration logic
  app.get("/api/streak", checkAuth, async (req: any, res) => {
    try {
      const userId = "admin";
      let streak = await storage.getUserStreak(userId);
      
      if (!streak) {
        streak = await storage.initializeUserStreak(userId);
      }

      // Check if streak is dead and can be restored
      const now = new Date();
      const lastActivity = streak.lastActiveDate ? new Date(streak.lastActiveDate) : null;
      const isDead = lastActivity ? (now.getTime() - lastActivity.getTime()) > 24 * 60 * 60 * 1000 : false;
      
      let canRestore = false;
      let hoursLeftToRestore = 0;
      let applicationsNeededToRestore = 0;
      
      if (isDead && lastActivity) {
        const timeSinceDead = now.getTime() - lastActivity.getTime();
        const hoursDeadFor = timeSinceDead / (1000 * 60 * 60);
        
        // Can restore within 48 hours of streak death
        canRestore = hoursDeadFor <= 48;
        hoursLeftToRestore = Math.max(0, Math.ceil(48 - hoursDeadFor));
        
        // Check how many applications completed in last 48 hours
        if (canRestore) {
          const fortyEightHoursAgo = new Date(now.getTime() - 48 * 60 * 60 * 1000);
          const recentProgress = await storage.getProgressEntriesSince(userId, fortyEightHoursAgo);
          const totalRecent = recentProgress.reduce((sum, entry) => sum + entry.amount, 0);
          applicationsNeededToRestore = Math.max(0, 150 - totalRecent);
        }
      }

      res.json({
        ...streak,
        isDead,
        canRestore,
        hoursLeftToRestore,
        applicationsNeededToRestore
      });
    } catch (error) {
      console.error("Error fetching user streak:", error);
      res.status(500).json({ message: "Failed to fetch streak" });
    }
  });

  // Helper function to update user streak
  async function updateUserStreakForToday(userId: string, amount: number) {
    try {
      let streak = await storage.getUserStreak(userId);
      
      if (!streak) {
        streak = await storage.initializeUserStreak(userId);
      }

      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const lastActiveDate = streak.lastActiveDate ? new Date(streak.lastActiveDate) : null;
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);

      // Check if user already added progress today
      if (lastActiveDate && lastActiveDate.getTime() === today.getTime()) {
        return; // Already counted for today
      }

      // Calculate new streak
      let newStreak = streak.currentStreak;
      
      if (!lastActiveDate || lastActiveDate.getTime() === yesterday.getTime()) {
        // Continue streak or start new one
        newStreak += 1;
      } else if (lastActiveDate.getTime() < yesterday.getTime()) {
        // Streak broken, reset to 1
        newStreak = 1;
      }

      // Only count if amount is >= 50
      if (amount >= 50) {
        await storage.updateUserStreak(userId, newStreak, today);
      }
    } catch (error) {
      console.error("Error updating user streak:", error);
    }
  }

  // Client sharing routes - no authentication required
  app.get("/api/public/client/:shareToken", async (req: any, res) => {
    try {
      const { shareToken } = req.params;
      const client = await storage.getClientByShareToken(shareToken);
      
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }

      // Return limited client data for public view
      const publicData = {
        id: client.id,
        name: client.name,
        appAmount: client.appAmount,
        appDone: client.appDone,
        isCompleted: client.isCompleted,
        appDay: client.appDay,
        appTime: client.appTime,
        createdAt: client.createdAt,
      };

      res.json(publicData);
    } catch (error) {
      console.error("Error fetching public client:", error);
      res.status(500).json({ message: "Failed to fetch client" });
    }
  });

  app.get("/api/public/client/:shareToken/history", async (req: any, res) => {
    try {
      const { shareToken } = req.params;
      const client = await storage.getClientByShareToken(shareToken);
      
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }

      const history = await storage.getProgressHistory(client.id);
      res.json(history);
    } catch (error) {
      console.error("Error fetching public client history:", error);
      res.status(500).json({ message: "Failed to fetch client history" });
    }
  });

  // Generate share link for client
  app.post("/api/clients/:id/share", checkAuth, async (req: any, res) => {
    try {
      const clientId = req.params.id;
      const userId = "admin";
      
      // Verify client belongs to user
      const client = await storage.getClient(clientId);
      if (!client || client.userId !== userId) {
        return res.status(404).json({ message: "Client not found" });
      }

      // Generate share token and update client
      const shareToken = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
      await storage.updateClientShareToken(clientId, shareToken);

      const shareUrl = `${req.protocol}://${req.hostname}/share/${shareToken}`;
      res.json({ shareUrl, shareToken });
    } catch (error) {
      console.error("Error generating share link:", error);
      res.status(500).json({ message: "Failed to generate share link" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
