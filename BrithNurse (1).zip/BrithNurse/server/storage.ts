import {
  users,
  clients,
  progressHistory,
  userStreaks,
  type User,
  type UpsertUser,
  type InsertClient,
  type Client,
  type ProgressHistory,
  type UserStreak,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Client operations
  createClient(userId: string, client: InsertClient): Promise<Client>;
  getClientsByUserId(userId: string): Promise<Client[]>;
  getClient(id: string): Promise<Client | undefined>;
  updateClientProgress(clientId: string, amount: number): Promise<Client>;
  
  // Progress history operations
  addProgressHistory(clientId: string, amount: number): Promise<ProgressHistory>;
  getProgressHistory(clientId: string): Promise<ProgressHistory[]>;
  
  // User streak operations
  getUserStreak(userId: string): Promise<UserStreak | undefined>;
  updateUserStreak(userId: string, streak: number, lastActiveDate: Date): Promise<UserStreak>;
  initializeUserStreak(userId: string): Promise<UserStreak>;
  getProgressEntriesSince(userId: string, since: Date): Promise<ProgressHistory[]>;
  
  // Client sharing operations
  getClientByShareToken(shareToken: string): Promise<Client | undefined>;
  updateClientShareToken(clientId: string, shareToken: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Client operations
  async createClient(userId: string, clientData: InsertClient): Promise<Client> {
    const [client] = await db
      .insert(clients)
      .values({
        ...clientData,
        userId,
      })
      .returning();
    return client;
  }

  async getClientsByUserId(userId: string): Promise<Client[]> {
    return await db
      .select()
      .from(clients)
      .where(eq(clients.userId, userId))
      .orderBy(desc(clients.createdAt));
  }

  async getClient(id: string): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.id, id));
    return client;
  }

  async updateClientProgress(clientId: string, amount: number): Promise<Client> {
    const client = await this.getClient(clientId);
    if (!client) {
      throw new Error("Client not found");
    }

    const newAppDone = client.appDone + amount;
    const isCompleted = newAppDone >= client.appAmount;

    const [updatedClient] = await db
      .update(clients)
      .set({
        appDone: newAppDone,
        isCompleted,
        updatedAt: new Date(),
      })
      .where(eq(clients.id, clientId))
      .returning();

    return updatedClient;
  }

  // Progress history operations
  async addProgressHistory(clientId: string, amount: number): Promise<ProgressHistory> {
    const [history] = await db
      .insert(progressHistory)
      .values({
        clientId,
        amount,
      })
      .returning();
    return history;
  }

  async getProgressHistory(clientId: string): Promise<ProgressHistory[]> {
    return await db
      .select()
      .from(progressHistory)
      .where(eq(progressHistory.clientId, clientId))
      .orderBy(desc(progressHistory.createdAt));
  }

  // User streak operations
  async getUserStreak(userId: string): Promise<UserStreak | undefined> {
    const [streak] = await db
      .select()
      .from(userStreaks)
      .where(eq(userStreaks.userId, userId));
    return streak;
  }

  async updateUserStreak(userId: string, streak: number, lastActiveDate: Date): Promise<UserStreak> {
    const [updatedStreak] = await db
      .update(userStreaks)
      .set({
        currentStreak: streak,
        lastActiveDate,
        updatedAt: new Date(),
      })
      .where(eq(userStreaks.userId, userId))
      .returning();
    return updatedStreak;
  }

  async initializeUserStreak(userId: string): Promise<UserStreak> {
    const [streak] = await db
      .insert(userStreaks)
      .values({
        userId,
        currentStreak: 0,
      })
      .returning();
    return streak;
  }

  async getProgressEntriesSince(userId: string, since: Date): Promise<ProgressHistory[]> {
    // Get all clients for this user first
    const userClients = await db
      .select()
      .from(clients)
      .where(eq(clients.userId, userId));
    
    if (userClients.length === 0) return [];
    
    const clientIds = userClients.map(c => c.id);
    
    // Get progress entries since the given date for user's clients
    return await db
      .select()
      .from(progressHistory)
      .where(
        and(
          gte(progressHistory.createdAt, since)
        )
      )
      .orderBy(desc(progressHistory.createdAt));
  }

  async getClientByShareToken(shareToken: string): Promise<Client | undefined> {
    const [client] = await db
      .select()
      .from(clients)
      .where(eq(clients.shareToken, shareToken));
    return client;
  }

  async updateClientShareToken(clientId: string, shareToken: string): Promise<void> {
    await db
      .update(clients)
      .set({ shareToken })
      .where(eq(clients.id, clientId));
  }
}

export const storage = new DatabaseStorage();
