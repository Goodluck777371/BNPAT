# replit.md

## Overview

BNPAT (Birth Nurse Pathway Application Tracker) is a full-stack web application designed to help birth nurses track their application progress through various programs. The application provides a dashboard for managing clients, tracking application completion, monitoring progress streaks, and generating shareable progress reports. Built with a modern tech stack, it features a React frontend with shadcn/ui components, an Express.js backend with PostgreSQL database integration via Drizzle ORM, and Replit authentication for secure user management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development practices
- **Routing**: Wouter for lightweight client-side routing with conditional rendering based on authentication state
- **UI Framework**: shadcn/ui component library built on Radix UI primitives with Tailwind CSS for consistent styling
- **State Management**: TanStack Query (React Query) for server state management, caching, and API synchronization
- **Form Handling**: React Hook Form with Zod validation for type-safe form processing
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API endpoints
- **Database ORM**: Drizzle ORM with PostgreSQL dialect for type-safe database operations
- **Authentication**: Replit Auth with OpenID Connect for secure user authentication and session management
- **Session Storage**: PostgreSQL-backed sessions using connect-pg-simple for persistent user sessions
- **Database Connection**: Neon serverless PostgreSQL with WebSocket support for scalable database connectivity

### Data Storage Solutions
- **Primary Database**: PostgreSQL with the following schema design:
  - Users table (mandatory for Replit Auth) with profile information
  - Sessions table (mandatory for Replit Auth) for session persistence  
  - Clients table for tracking application targets and progress
  - Progress history table for recording incremental updates
  - User streaks table for gamification and engagement tracking
- **Database Migrations**: Drizzle Kit for schema management and version control
- **Connection Pooling**: Neon connection pooling for efficient database resource utilization

### Authentication and Authorization
- **Provider**: Replit Auth integration with OpenID Connect protocol
- **Session Management**: Secure HTTP-only cookies with PostgreSQL session storage
- **Authorization Pattern**: Middleware-based route protection with user context injection
- **User Profile**: Automatic user creation/update on successful authentication

### API Design
- **Pattern**: RESTful API with resource-based endpoints
- **Authentication Routes**: `/api/auth/user` for user profile retrieval
- **Client Management**: CRUD operations for client tracking at `/api/clients`
- **Progress Tracking**: Dedicated endpoints for progress updates and history
- **Error Handling**: Centralized error middleware with structured error responses
- **Request Logging**: Custom middleware for API request/response logging

### Development and Build Process
- **Development Server**: Vite dev server with HMR for fast frontend development
- **Build Process**: Separate frontend (Vite) and backend (esbuild) build pipelines
- **Path Resolution**: TypeScript path mapping for clean imports (@, @shared aliases)
- **Type Safety**: Shared TypeScript schemas between frontend and backend via Drizzle Zod integration

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL provider with WebSocket support for scalable database hosting
- **Connection Library**: @neondatabase/serverless for optimized Neon database connectivity

### Authentication Services  
- **Replit Authentication**: Integrated OAuth provider using OpenID Connect for user authentication
- **Session Storage**: connect-pg-simple for PostgreSQL-backed session persistence

### Frontend Libraries
- **UI Components**: Comprehensive shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Icons**: Lucide React for consistent iconography
- **Date Handling**: date-fns for date formatting and manipulation
- **Form Validation**: Zod schema validation with React Hook Form integration

### Development Tools
- **TypeScript**: Full-stack type safety with shared schema definitions
- **Drizzle Kit**: Database migration and introspection tooling
- **PostCSS**: CSS processing with Tailwind CSS and Autoprefixer plugins
- **ESBuild**: Fast backend bundling for production deployments

### Runtime Dependencies
- **Express Middleware**: Standard middleware for JSON parsing, URL encoding, and CORS
- **Security**: Helmet.js equivalent functionality through custom middleware
- **Utilities**: Class variance authority for component variant management, clsx for conditional styling